# Integrations and SDK — ENCODEC

**Company:** Anticloud FZ LLE
**Model:** PAX L5 Narrow L2 General 27B
**Project:** ENCODEC | Category: AUDIO_CONSUMER
**Upstream:** https://github.com/facebookresearch/encodec (MIT)

## Overview

This document covers integrations and sdk for the Anticloud integration of ENCODEC.

Neural audio codec by Meta

## Anticloud Integration

PAX L5 Narrow L2 General 27B is integrated into ENCODEC to provide:
- Local AI inference with zero cloud dependency
- AIOSS tamper-evident audit chain
- AES-256 encryption at rest
- Single-binary deployment

## Contact

Lois-Kleinner Alpasan — CEO & CTO, Anticloud FZ LLE
lois@0-1.gg | 0-1.gg
