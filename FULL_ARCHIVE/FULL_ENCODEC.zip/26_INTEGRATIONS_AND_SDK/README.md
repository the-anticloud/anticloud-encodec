# 26 Integrations And Sdk

**Project:** ENCODEC
**Upstream:** https://github.com/facebookresearch/encodec

Content specific to ENCODEC in category AUDIO_CONSUMER.
