# 06 Whitelabelling And Repackaging

**Project:** ENCODEC
**Upstream:** https://github.com/facebookresearch/encodec

Content specific to ENCODEC in category AUDIO_CONSUMER.
